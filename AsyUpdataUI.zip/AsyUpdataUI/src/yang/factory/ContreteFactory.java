package yang.factory;

import android.os.Handler;

public class ContreteFactory extends Factory{

	//	protected  UserFactory(String productSign) {
	//		// TODO Auto-generated constructor stub
	//	}
	@Override
	public Pruduct ingredientPruduct(String item) {
		// TODO Auto-generated method stub
		if(item.equals("ingredient"))
			return new UserPortraitProduct();
		else if(item.equals("user"))
			return new UserProduct();
		else 
			return null;
	}

}
