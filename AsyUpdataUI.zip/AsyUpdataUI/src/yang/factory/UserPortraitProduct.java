package yang.factory;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;

public class UserPortraitProduct extends Pruduct{
    //��ȡ�ɹ�massage
    private int SUCCESS_MSG = 1;
    //��ȡʧ�ܷ���massage
    private int FAILURE_MSG = 0;
    
	private String URL;
	private Handler mHandler;

	@Override
	public void setURLparameter(String URL,Handler mHandler) {
		this.URL = URL;
		this.mHandler = mHandler;
		 getDatabyURL();
	}

	@Override
	public void getDatabyURL() {
		
		new Thread(){
			 @Override
			    public void run() {
				 try {
					sleep(3000);
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			        try {
			            URL url =new URL(URL);
			            //��ȡ���Ӷ���
			            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
			            //��������ʽ
			            urlConnection.setRequestMethod("GET");
			            //���ÿɽ�������
			            urlConnection.setDoInput(true);
			            //���ó�ʱʱ��
			            urlConnection.setConnectTimeout(5*1000);
			            //����״̬���ж��Ƿ�����ɹ�
			            if (urlConnection.getResponseCode() == 200){
			                //��ȡ��Ӧ������
			                InputStream is=urlConnection.getInputStream();
			                //��ͼƬ��ת����λͼ����
			                Bitmap bitmap= BitmapFactory.decodeStream(is);

			                /*
			                ������Ч����ͬ
			                Message msg = mHandler.obtainMessage();
			                msg.obj = bitmap;
			                msg.arg1 = SUCCESS_MSG;
			                mHandler.sendMessage(msg);
			                */

			                //obtainMessage(int what, Object obj)
			                //what:��ʾ����
			                //Object���������ݶ���
			                mHandler.obtainMessage(SUCCESS_MSG,bitmap).sendToTarget();

			            }else {
			                //��ȡͼƬʧ�ܷ���ʧ��massage
			                mHandler.obtainMessage(FAILURE_MSG).sendToTarget();
			            }
			        } catch (MalformedURLException e) {
			            e.printStackTrace();
			        } catch (IOException e) {
			            e.printStackTrace();
			        }
			    }
		}.start();;
		
		
		
		
		
	}

	@Override
	public void setURLparameter() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setURLparameter(Handler mHandler) {
		// TODO Auto-generated method stub
		
	}

}
