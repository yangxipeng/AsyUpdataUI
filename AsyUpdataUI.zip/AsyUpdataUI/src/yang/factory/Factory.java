package yang.factory;

public abstract class Factory {
	public abstract Pruduct ingredientPruduct(String item); 
}
