package yang.factory;

import android.os.Handler;

public abstract class Pruduct  {
	public abstract void getDatabyURL(); 
	public abstract void setURLparameter(); 
	public abstract void setURLparameter(Handler mHandler); 
	public abstract void setURLparameter(String URL,Handler mHandler); 
}
