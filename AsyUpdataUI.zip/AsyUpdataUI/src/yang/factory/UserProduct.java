package yang.factory;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;







import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Message;

public class UserProduct extends Pruduct{
	private String URL;
	private Handler mHandler;
	
    //��ȡ�ɹ�massage
    private int SUCCESS_MSG = 1;
    //��ȡʧ�ܷ���massage
    private int FAILURE_MSG = 0;
	@Override
	public void getDatabyURL() {
		// TODO Auto-generated method stub
		new Thread(){
			 @Override
			    public void run() {
			
			        try {
			            URL url =new URL(URL);
			            //��ȡ���Ӷ���
			            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
			            //��������ʽ
			            urlConnection.setRequestMethod("GET");
			            //���ÿɽ�������
			            urlConnection.setDoInput(true);
			            //�����ַ���
			            urlConnection.setRequestProperty("Charset", "UTF-8");
			            //���ó�ʱʱ��
			            urlConnection.setConnectTimeout(5*1000);
			            //����״̬���ж��Ƿ�����ɹ�
			            // �����ļ�����
			          //  urlConnection.setRequestProperty("Content-Type", "text/xml; charset=UTF-8");
			            if (urlConnection.getResponseCode() == 200){
			                //��ȡ��Ӧ������
			                InputStream is=urlConnection.getInputStream();
			                
			                
			               String result = inputStream2String(is);
		                    
			               mHandler.obtainMessage(SUCCESS_MSG,result).sendToTarget();

			            }else {
			                //��ȡͼƬʧ�ܷ���ʧ��massage
			                mHandler.obtainMessage(FAILURE_MSG).sendToTarget();
			            }
			        } catch (MalformedURLException e) {
			            e.printStackTrace();
			        } catch (IOException e) {
			            e.printStackTrace();
			        }
			    }
		}.start();;
		
		
	}

	@Override
	public void setURLparameter() {
		// TODO Auto-generated method stub
		System.out.println("�����������");
	}

	@Override
	public void setURLparameter(Handler mHandler) {
		// TODO Auto-generated method stub


	}

	@Override
	public void setURLparameter(final String URL, Handler mHandler) {
		this.URL = URL;
		this.mHandler = mHandler;
		getDatabyURL();
	}
	public   static   String   inputStream2String(InputStream   is)   throws   IOException{ 
        ByteArrayOutputStream   baos   =   new   ByteArrayOutputStream(); 
        int   i=-1; 
        while((i=is.read())!=-1){ 
        baos.write(i); 
        } 
       return   baos.toString(); 
}
}
