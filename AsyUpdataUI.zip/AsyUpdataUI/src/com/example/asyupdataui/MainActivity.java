package com.example.asyupdataui;



import org.xutils.x;
import org.xutils.view.annotation.ContentView;

import yang.factory.Factory;
import yang.factory.Pruduct;
import yang.factory.ContreteFactory;
import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

//@ContentView(R.layout.activity_main)
public class MainActivity extends Activity {
	private ImageView imageView;
	private Button button;
	TextView text;
	private DownloadImgThread mThread;
	private String image_url ="http://pic43.nipic.com/20140708/4481651_113707494582_2.jpg";
	private String text_url = "http://1.isports.applinzi.com/yang.php";
	private Handler mHandler;
	private final String DEBUG = "debug";
	Handler mHandler2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		imageView = (ImageView) findViewById(R.id.imageView);
		button = (Button) findViewById(R.id.button);
		text = (TextView) findViewById(R.id.text);
		
		//��ʼ��handler����ʵ�ֻش����ݽ��պ�UI����
		mHandler = new Handler(){
			//�̳�ʵ��Handler��handleMessage�������÷�����UI�߳���ִ��
			@Override
			public void handleMessage(Message msg) {
				//�����̻߳ش��ĵı�ʾ��Ϣ����Ӧ��UI����
				switch (msg.what){
				case 1:
					//����ͼƬ���ݵ�UI��ʾ
					imageView.setImageBitmap((Bitmap) msg.obj);
					//text.setText((String)msg.obj);
					Log.d(DEBUG,msg.getTarget().toString());
					break;
				case 0:
					Toast.makeText(MainActivity.this,"��ȡͼƬʧ��",Toast.LENGTH_SHORT).show();
					Log.d(DEBUG,"��ȡͼƬʧ��");
					break;
				}

			}
		};
		//���ü���
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
	
				Factory ingredientFactor = new ContreteFactory();
				ingredientFactor.ingredientPruduct("ingredient").setURLparameter(image_url, mHandler);

//				Factory userFactor = new ContreteFactory();
//				userFactor.ingredientPruduct("user").setURLparameter(text_url,mHandler);
			}
		});

	}
}


